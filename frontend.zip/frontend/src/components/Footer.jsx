import React from 'react';
import { Link } from 'react-router-dom';
// import { Package, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="glass border-t border-white/5 py-16 px-6 relative overflow-hidden">
      {/* Decorative Orbs */}
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-[100px]"></div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
        <div>
          <div className="flex items-center gap-2 mb-6">
            <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
              {/* <Package className="text-black" size={20} /> */}
            </div>
            <span className="text-2xl font-black gradient-text">Gofs HairCare</span>
          </div>
          <p className="text-white/40 mb-8 max-w-xs">
            Authentic Ayurvedic and natural hair care solutions for a healthier, more vibrant you. Experience the fusion of tradition and science.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full glass border border-white/10 flex items-center justify-center hover:bg-green-500/20 hover:text-green-400 transition-all">
              {/* <Instagram size={18} /> */}
            </a>
            <a href="#" className="w-10 h-10 rounded-full glass border border-white/10 flex items-center justify-center hover:bg-green-500/20 hover:text-green-400 transition-all">
              {/* <Twitter size={18} /> */}
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6">Quick Links</h4>
          <ul className="space-y-4 text-white/60">
            <li><Link to="/" className="hover:text-green-400 transition-colors">Home</Link></li>
            <li><Link to="/#products" className="hover:text-green-400 transition-colors">Shop</Link></li>
            <li><Link to="/about" className="hover:text-green-400 transition-colors">Our Story</Link></li>
            <li><Link to="/admin" className="hover:text-green-400 transition-colors">Admin Portal</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6">Support</h4>
          <ul className="space-y-4 text-white/60">
            <li><a href="#" className="hover:text-green-400 transition-colors">Shipping Policy</a></li>
            <li><a href="#" className="hover:text-green-400 transition-colors">Returns & Refunds</a></li>
            <li><a href="#" className="hover:text-green-400 transition-colors">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-green-400 transition-colors">Terms of Service</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6">Contact Us</h4>
          <ul className="space-y-4 text-white/60">
            <li className="flex items-center gap-3">
              {/* <MapPin size={18} className="text-green-400" /> */}
              <span>123 Ayurvedic Lane, Tamil Nadu, India</span>
            </li>
            <li className="flex items-center gap-3">
              {/* <Phone size={18} className="text-green-400" /> */}
              <span>+91 98765 43210</span>
            </li>
            <li className="flex items-center gap-3">
              {/* <Mail size={18} className="text-green-400" /> */}
              <span>greensignaltamil@gmail.com</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-white/20 text-sm">
        <p>&copy; 2026 Gofs HairCare. All rights reserved.</p>
        <div className="flex gap-8">
          <a href="#" className="hover:text-white/40">Privacy</a>
          <a href="#" className="hover:text-white/40">Terms</a>
          <a href="#" className="hover:text-white/40">Sitemap</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
