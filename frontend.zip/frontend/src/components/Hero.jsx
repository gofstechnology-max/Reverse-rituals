import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-[#0c0c0e] px-6 pt-16">
      {/* Background Animated Orbs */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-green-500/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[150px] animate-bounce-slow"></div>

      <div className="max-w-7xl mx-auto flex flex-col items-center justify-center text-center relative z-10 w-full">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8 }}
           className="inline-flex items-center gap-2 px-6 py-2 rounded-full glass border border-white/10 text-green-400 mb-8 w-fit"
        >
          <Sparkles size={16} className="animate-pulse" />
          <span className="font-semibold uppercase tracking-wider text-sm">Experience the Hair Transformation</span>
        </motion.div>

        <motion.h1
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           className="text-5xl md:text-8xl font-black mb-6 leading-tight tracking-tighter"
        >
          Natural Science for <br />
          <span className="gradient-text drop-shadow-[0_0_20px_rgba(34,197,94,0.3)]">Your Hair Health.</span>
        </motion.h1>

        <motion.p
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, delay: 0.4 }}
           className="max-w-2xl text-lg md:text-xl text-white/60 mb-12"
        >
          Discover the power of nature with Gofs HairCare. Our Rosemary Water and Neem Wood products are meticulously crafted to rejuvenate and strengthen your hair from within.
        </motion.p>

        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 0.8, delay: 0.6 }}
           className="flex flex-col sm:flex-row gap-6 w-full sm:w-auto"
        >
          <a href="#products" className="btn-primary group flex items-center justify-center gap-2">
            Shop Products
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </a>
          <button className="btn-secondary">Learn More</button>
        </motion.div>
      </div>

      {/* Decorative Floating Elements */}
      <motion.div
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 5, repeat: Infinity }}
        className="absolute bottom-20 left-10 md:left-20 glass p-6 rounded-2xl hidden lg:block"
      >
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
             <span className="text-2xl">🌱</span>
           </div>
           <div>
             <p className="font-bold">100% Organic</p>
             <p className="text-white/40 text-sm">Pure Natural Ingredients</p>
           </div>
        </div>
      </motion.div>
    </section>
  );
};

export default Hero;
