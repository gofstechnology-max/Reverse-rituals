import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Star, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { toast } from 'react-toastify';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    addToCart(product);
    toast.success(`${product.name} added to cart!`, {
      position: "bottom-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      theme: "dark",
    });
  };

  return (
    <motion.div
       whileHover={{ y: -10 }}
       transition={{ duration: 0.3 }}
       className="glass rounded-3xl overflow-hidden flex flex-col h-full hover:border-green-500/30 transition-colors group relative"
    >
      <Link to={`/product/${product._id}`} className="block relative overflow-hidden aspect-[4/5] sm:aspect-square md:aspect-[4/5]">
        <img
           src={product.image}
           alt={product.name}
           className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
           {product._id.includes('alchemy') || product._id.includes('neem') || product._id.includes('scalp') || product._id.includes('combo') ? (
              <div className="bg-green-500 text-black text-[10px] font-black uppercase tracking-tighter px-3 py-1 rounded-full shadow-lg shadow-green-500/40">
                Alchemy Original
              </div>
           ) : null}
        </div>
        <div className="absolute top-4 right-4 z-10">
           <div className="glass px-3 py-1 rounded-full flex items-center gap-1 text-sm bg-black/40 border-white/20 backdrop-blur-md">
             <Star size={14} className="fill-yellow-400 text-yellow-400" />
             <span className="font-bold">{product.rating}</span>
           </div>
        </div>
      </Link>

      <div className="p-6 flex flex-col flex-grow">
        <Link to={`/product/${product._id}`} className="text-xl font-bold mb-2 group-hover:text-green-400 transition-colors">
          {product.name}
        </Link>
        <p className="text-white/40 text-sm mb-6 line-clamp-2">
          {product.description}
        </p>

        <div className="mt-auto flex items-center justify-between">
           <div>
              <span className="text-2xl font-black text-green-400">₹{product.price}</span>
              {product.originalPrice && (
                 <span className="ml-2 text-sm text-white/30 line-through">₹{product.originalPrice}</span>
              )}
           </div>
           <button
              onClick={handleAddToCart}
              className="w-12 h-12 rounded-2xl bg-green-500 hover:bg-green-400 text-black flex items-center justify-center transition-all transform active:scale-95 shadow-lg shadow-green-500/20"
           >
             <Plus size={24} />
           </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
