import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User, LogOut, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const cartCount = cartItems.reduce((acc, item) => acc + item.qty, 0);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold tracking-tighter flex items-center gap-2 group">
          <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center transform group-hover:rotate-12 transition-transform">
             <Package className="text-black" size={24} />
          </div>
           <span className="gradient-text">Gofs HairCare</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link to="/" className="hover:text-green-400 transition-colors hidden md:block">Home</Link>
          <Link to="/#products" className="hover:text-green-400 transition-colors hidden md:block">Shop</Link>
          <Link to="/about" className="hover:text-green-400 transition-colors hidden md:block">About</Link>
          
          <Link to="/cart" className="relative group">
            <ShoppingCart className="group-hover:text-green-400 transition-colors" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-green-500 text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Link>

          {user ? (
            <div className="flex items-center gap-4">
               <Link to="/orders" className="flex items-center gap-2 hover:text-green-400 transition-colors">
                  <Package size={20} />
                  <span className="hidden sm:inline">Orders</span>
               </Link>
               <Link to={user.isAdmin ? "/admin" : "/orders"} className="flex items-center gap-2 hover:text-green-400 transition-colors">
                  <User size={20} />
                  <span className="hidden sm:inline">{user.name}</span>
               </Link>
               <button onClick={logout} className="hover:text-red-400 transition-colors">
                 <LogOut size={20} />
               </button>
            </div>
          ) : (
            <Link to="/login" className="flex items-center gap-2 hover:text-green-400 transition-colors">
              <User size={20} />
              <span>Login</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
