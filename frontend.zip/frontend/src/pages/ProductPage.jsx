import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { motion } from 'framer-motion';
import { ShoppingCart, Star, CheckCircle, Info, ArrowLeft, Plus, Minus, Leaf, Zap } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { toast } from 'react-toastify';

import { alchemyProducts } from '../data/alchemyProducts';

const ProductPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchProduct = async () => {
      // Check local alchemy products first
      const localProduct = alchemyProducts.find(p => p._id === id);
      if (localProduct) {
        setProduct(localProduct);
        setLoading(false);
        return;
      }

      try {
        const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
        const { data } = await axios.get(`${API_URL}/api/products/${id}`);
        setProduct(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching product:', error);
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast.success(`${product.name} added to cart!`, {
      icon: <ShoppingCart size={20} className="text-green-400" />
    });
  };

  if (loading) return <div className="h-screen pt-32 flex items-center justify-center"><div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div></div>;
  if (!product) return <div className="h-screen pt-32 text-center">Product not found</div>;

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto">
      <Link to="/" className="inline-flex items-center gap-2 text-white/40 hover:text-green-400 mb-12 transition-colors">
        <ArrowLeft size={20} /> Back to Shop
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 0.5 }}
           className="glass rounded-[3rem] p-4 border-white/10 group overflow-hidden"
        >
          <img src={product.image} alt={product.name} className="w-full h-[600px] object-cover rounded-[2.5rem] group-hover:scale-105 transition-transform duration-700" />
        </motion.div>

        <motion.div
           initial={{ opacity: 0, x: 20 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.5, delay: 0.2 }}
        >
          <span className="text-green-500 font-bold uppercase tracking-widest text-sm mb-4 block">{product.category}</span>
          <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight tracking-tighter">{product.name}</h1>
          
          <div className="flex items-center gap-6 mb-8 p-4 glass rounded-2xl border-white/5 w-fit">
             <div className="flex items-center gap-1">
                <Star size={20} className="fill-yellow-400 text-yellow-400" />
                <span className="text-xl font-bold">{product.rating}</span>
             </div>
             <div className="w-px h-6 bg-white/10"></div>
             <span className="text-white/40 font-bold">{product.numReviews} Reviews</span>
             <div className="w-px h-6 bg-white/10"></div>
             <span className="text-green-400 font-bold">In Stock</span>
          </div>

          <p className="text-white/60 text-xl leading-relaxed mb-10">
            {product.description}
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-8 mb-12">
             <div className="text-4xl font-black gradient-text">₹{product.price}</div>
             <div className="flex items-center glass rounded-2xl border-white/10 p-1">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-12 flex items-center justify-center hover:bg-white/5 rounded-xl transition-colors"
                >
                   <Minus size={20} />
                </button>
                <span className="px-6 text-xl font-bold">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-12 h-12 flex items-center justify-center hover:bg-white/5 rounded-xl transition-colors"
                >
                   <Plus size={20} />
                </button>
             </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 mb-16">
             <button onClick={handleAddToCart} className="btn-primary flex-1 flex items-center justify-center gap-4">
                <ShoppingCart size={24} />
                Add to Cart
             </button>
             <button className="btn-secondary flex items-center justify-center gap-2">
                <Star size={24} className="text-yellow-400" />
                Add to Wishlist
             </button>
          </div>

          {/* Key Benefits Grid */}
          <div className="p-8 glass rounded-3xl border-white/5 bg-white/5 mb-8">
             <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
               <CheckCircle className="text-green-400" /> 
               {product.ingredients?.length > 0 ? "Ingredients & Power" : "Key Benefits"}
             </h3>
             <ul className="space-y-4">
                {product.features?.map((feature, i) => (
                   <li key={i} className="flex items-start gap-3 text-white/70">
                      <CheckCircle size={20} className="text-green-500 shrink-0 mt-1" />
                      <span className="text-lg">{feature}</span>
                   </li>
                ))}
             </ul>
          </div>

          {/* Usage Tips */}
          {product.usageTips?.length > 0 && (
            <div className="p-8 glass rounded-3xl border-emerald-500/10 bg-emerald-500/5 mb-8">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-green-400">
                  <Info size={20} /> Usage Tips
                </h3>
                <ul className="space-y-2">
                   {product.usageTips.map((tip, i) => (
                      <li key={i} className="text-white/60 flex items-start gap-2">
                         <span className="text-green-500">•</span> {tip}
                      </li>
                   ))}
                </ul>
            </div>
          )}
        </motion.div>
      </div>

      {/* Dynamic Content Sections */}
      <section className="mt-32 space-y-32">
         {/* Ingredients Detailed Section */}
         {product.ingredients?.length > 0 && (
            <div>
               <div className="text-center mb-16 relative">
                  <div className="absolute inset-0 flex items-center justify-center -z-10">
                     <div className="w-64 h-64 bg-green-500/10 rounded-full blur-[100px]"></div>
                  </div>
                  <h2 className="text-4xl md:text-7xl font-black tracking-tighter mb-4 italic">The <span className="gradient-text">Alchemy</span> of Nature</h2>
                  <p className="text-white/40 text-xl max-w-2xl mx-auto">Every ingredient is selected for clinical efficacy and centuries-old Ayurvedic tradition.</p>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {product.ingredients.map((ing, i) => (
                     <motion.div 
                        key={i}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        whileHover={{ y: -10, scale: 1.02 }}
                        className="p-10 glass rounded-[2.5rem] border-white/5 bg-gradient-to-br from-white/[0.03] to-transparent group"
                     >
                        <div className="flex items-center gap-4 mb-6">
                           <div className="w-14 h-14 bg-green-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-green-500/10">
                              <Leaf className="text-green-400" size={28} />
                           </div>
                           <div>
                              <h4 className="text-2xl font-bold">{ing.name}</h4>
                              <p className="text-green-500/70 text-xs font-bold uppercase tracking-widest leading-tight">{ing.description}</p>
                           </div>
                        </div>
                        <ul className="space-y-3">
                           {ing.points?.map((p, j) => (
                              <li key={j} className="text-white/50 text-sm flex items-start gap-3 leading-relaxed">
                                 <CheckCircle size={16} className="text-green-500/40 shrink-0 mt-0.5" />
                                 {p}
                              </li>
                           ))}
                        </ul>
                     </motion.div>
                  ))}
               </div>
            </div>
         )}

         {/* Overall Effect Section (For Alchemy Water) */}
         {product.overallEffect?.length > 0 && (
            <div className="p-12 glass rounded-[4rem] border-green-500/10 bg-green-500/5 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-[80px] -mr-10 -mt-10 group-hover:scale-125 transition-transform duration-1000"></div>
                <div className="text-center mb-16 relative z-10">
                   <h2 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter">The <span className="gradient-text italic">Synergy</span> Effect</h2>
                   <p className="text-white/40 text-lg">Harmonized ingredients working in unison for total hair transformation.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
                   {product.overallEffect.map((effect, i) => (
                      <motion.div 
                        key={i}
                        whileHover={{ x: 10 }}
                        className="flex items-center gap-6 p-8 bg-white/5 rounded-3xl border border-white/5 hover:bg-white/[0.08] transition-colors"
                      >
                         <div className="w-4 h-4 rounded-full bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.8)] animate-pulse"></div>
                         <span className="text-xl text-white/80 font-bold tracking-tight">{effect}</span>
                      </motion.div>
                   ))}
                </div>
            </div>
         )}

         {/* Benefits Detailed Section */}
         {product.benefits?.length > 0 && (
            <div>
               <div className="text-center mb-16 relative">
                  <div className="absolute inset-0 flex items-center justify-center -z-10">
                     <div className="w-64 h-64 bg-blue-500/5 rounded-full blur-[100px]"></div>
                  </div>
                  <h2 className="text-4xl md:text-7xl font-black tracking-tighter mb-4 italic">Visible <span className="text-blue-400">Transformation</span></h2>
                  <p className="text-white/40 text-xl">Results you can see and feel within weeks of consistent ritual.</p>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {product.benefits.map((ben, i) => (
                     <motion.div 
                        key={i}
                        whileInView={{ opacity: 1, x: 0 }}
                        initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                        whileHover={{ scale: 1.02 }}
                        className="p-12 glass rounded-[3.5rem] border-white/5 flex flex-col md:flex-row gap-10 items-start bg-gradient-to-br from-white/[0.03] to-transparent hover:border-blue-500/20 transition-all"
                     >
                        <div className="w-20 h-20 bg-blue-500/10 rounded-[2rem] flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/10">
                           <Zap className="text-blue-400" size={40} />
                        </div>
                        <div>
                           <h4 className="text-3xl font-black mb-4 tracking-tight">{ben.title}</h4>
                           <p className="text-white/60 mb-8 text-lg leading-relaxed">{ben.description}</p>
                           <div className="flex flex-wrap gap-4">
                              {ben.points?.map((p, j) => (
                                 <span key={j} className="px-5 py-2.5 bg-blue-500/10 rounded-2xl text-sm font-bold text-blue-300 border border-blue-500/20">
                                    {p}
                                 </span>
                              ))}
                           </div>
                        </div>
                     </motion.div>
                  ))}
               </div>
            </div>
         )}

         {/* Manual Advantage Section (For Massager) */}
         {product.manualAdvantage?.length > 0 && (
            <div className="p-16 glass rounded-[4rem] border-blue-500/10 bg-gradient-to-br from-blue-500/5 to-transparent relative group">
                <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px] -mr-48 -mb-48 group-hover:scale-150 transition-transform duration-1000"></div>
                <div className="text-center mb-16">
                   <h2 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter">Why <span className="text-blue-400 italic">Manual</span> is Better</h2>
                   <p className="text-white/40 text-lg">Precision control for the most therapeutic scalp experience.</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                   {product.manualAdvantage.map((adv, i) => (
                      <motion.div 
                        key={i} 
                        whileHover={{ y: -10 }}
                        className="p-10 bg-white/5 rounded-[2.5rem] border border-white/5 text-center flex flex-col items-center justify-center group/card"
                      >
                         <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover/card:bg-blue-500/20 transition-colors">
                            <Star className="text-yellow-400" size={28} />
                         </div>
                         <span className="text-white text-xl font-black leading-tight">{adv}</span>
                      </motion.div>
                   ))}
                </div>
            </div>
         )}
         {/* Combo Items Section */}
         {product.comboItems?.length > 0 && (
            <div className="p-16 glass rounded-[4rem] border-white/10 bg-white/5 relative overflow-hidden">
                <div className="text-center mb-16">
                   <h2 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter">What's <span className="gradient-text italic">Inside</span></h2>
                   <p className="text-white/40 text-lg">The complete toolkit for your transformation journey.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                   {product.comboItems.map((item, i) => (
                      <motion.div 
                        key={i} 
                        whileHover={{ y: -10 }}
                        className="p-10 bg-white/5 rounded-[2.5rem] border border-white/5 text-center"
                      >
                         <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                            <CheckCircle className="text-green-400" size={32} />
                         </div>
                         <h4 className="text-2xl font-bold mb-2">{item.name}</h4>
                         <p className="text-white/40">{item.desc}</p>
                      </motion.div>
                   ))}
                </div>
            </div>
         )}
      </section>
    </div>
  );
};

export default ProductPage;
