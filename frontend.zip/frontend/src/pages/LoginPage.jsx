import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, LogIn, ArrowRight, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(email, password);
    if (result.success) {
      toast.success('Welcome back to Gofs HairCare!');
      navigate('/');
    } else {
      toast.error(result.message);
    }
  };

  return (
    <div className="h-screen pt-16 flex items-center justify-center relative px-6 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-green-500/5 rounded-full blur-[150px] animate-pulse"></div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass rounded-[3rem] p-12 md:p-20 border-white/10 w-full max-w-xl relative z-10 overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>

        <div className="flex flex-col items-center text-center mb-12">
           <div className="w-16 h-16 bg-green-500 rounded-2xl flex items-center justify-center mb-6 shadow-2xl shadow-green-500/30">
              <LogIn className="text-black" size={32} />
           </div>
           <h1 className="text-4xl font-black mb-4 tracking-tighter">Welcome Back!</h1>
           <p className="text-white/40">Enter your credentials to access your account.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
           <div className="relative group">
              <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-green-400 transition-colors" size={20} />
              <input 
                type="email" 
                required
                placeholder="Email Address" 
                className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
           </div>
           <div className="relative group">
              <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-green-400 transition-colors" size={20} />
              <input 
                type="password" 
                required
                placeholder="Password" 
                className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
           </div>

           <button type="submit" className="w-full btn-primary flex items-center justify-center gap-3 py-5 text-xl font-black">
              Sign In
              <ArrowRight size={24} className="animate-pulse" />
           </button>
        </form>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col items-center gap-6">
           <p className="text-white/40">Don't have an account yet?</p>
           <Link to="/signup" className="flex items-center gap-2 text-green-400 font-bold hover:gap-4 transition-all group">
              Create a free account 
              <ArrowRight size={20} />
           </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
