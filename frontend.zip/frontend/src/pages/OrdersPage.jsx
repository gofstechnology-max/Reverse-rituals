import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import { Package, Clock, CheckCircle, ChevronRight, ShoppingBag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        };
        const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
        const { data } = await axios.get(`${API_URL}/api/orders/myorders`, config);
        setOrders(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching orders:', error);
        setLoading(false);
      }
    };

    if (user) {
      fetchOrders();
    }
  }, [user]);

  if (loading) return <div className="h-screen pt-32 flex items-center justify-center"><div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div></div>;

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-4">
         <div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tighter">My <span className="gradient-text">Orders</span></h1>
            <p className="text-white/40 mt-2">Track your transformation journey.</p>
         </div>
         <Link to="/" className="btn-secondary flex items-center gap-2">
            <ShoppingBag size={20} /> Continue Shopping
         </Link>
      </div>

      {orders.length === 0 ? (
        <div className="glass p-20 rounded-[3rem] text-center border-white/5">
           <Package size={64} className="mx-auto text-white/10 mb-6" />
           <h3 className="text-2xl font-bold mb-4">No orders yet</h3>
           <p className="text-white/40 mb-8">Your first ritual is just a few clicks away.</p>
           <Link to="/" className="btn-primary inline-flex">Go to Shop</Link>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <motion.div 
               key={order._id}
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               className="glass rounded-[2.5rem] border-white/5 overflow-hidden group hover:border-green-500/30 transition-all hover:bg-white/[0.02]"
            >
               <div className="p-8 flex flex-col lg:flex-row gap-8 items-start lg:items-center">
                  {/* Order Info */}
                  <div className="flex-grow space-y-2">
                     <div className="flex items-center gap-3">
                        <span className="text-white/20 text-sm font-mono uppercase tracking-widest">Order ID: {order._id.slice(-8)}</span>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${order.isPaid ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-500'}`}>
                           {order.isPaid ? 'Paid' : 'Payment Pending'}
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${order.isDelivered ? 'bg-blue-500/20 text-blue-400' : 'bg-white/10 text-white/40'}`}>
                           {order.isDelivered ? 'Delivered' : 'Processing'}
                        </div>
                     </div>
                     <h3 className="text-2xl font-bold">Placed on {new Date(order.createdAt).toLocaleDateString()}</h3>
                     <p className="text-white/40 italic">₹{order.totalPrice} • {order.orderItems.length} items</p>
                  </div>

                  {/* Items Preview */}
                  <div className="flex -space-x-4 overflow-hidden">
                     {order.orderItems.slice(0, 3).map((item, i) => (
                        <div key={i} className="w-16 h-16 rounded-2xl border-4 border-[#0c0c0e] overflow-hidden bg-white/5">
                           <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                     ))}
                     {order.orderItems.length > 3 && (
                        <div className="w-16 h-16 rounded-2xl border-4 border-[#0c0c0e] bg-white/5 flex items-center justify-center text-xs font-bold text-white/40 backdrop-blur-xl">
                           +{order.orderItems.length - 3}
                        </div>
                     )}
                  </div>

                  {/* Status Steps */}
                  <div className="flex items-center gap-6 lg:ml-8">
                     <div className="flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${order.isPaid ? 'bg-green-500 text-black' : 'bg-white/5 text-white/20'}`}>
                           {order.isPaid ? <CheckCircle size={20} /> : <Clock size={20} />}
                        </div>
                        <span className="text-[10px] uppercase font-bold mt-2 tracking-tighter">Order</span>
                     </div>
                     <div className="w-8 h-px bg-white/10"></div>
                     <div className="flex flex-col items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${order.isDelivered ? 'bg-green-500 text-black' : 'bg-white/5 text-white/20'}`}>
                           {order.isDelivered ? <CheckCircle size={20} /> : <Package size={20} />}
                        </div>
                        <span className="text-[10px] uppercase font-bold mt-2 tracking-tighter">Shipping</span>
                     </div>
                  </div>
               </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrdersPage;
