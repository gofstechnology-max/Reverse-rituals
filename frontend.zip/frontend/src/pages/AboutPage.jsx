import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Heart, ShieldCheck, Zap, Quote } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto overflow-hidden">
      {/* Hero Section */}
      <div className="text-center mb-24">
         <motion.span 
           initial={{ opacity: 0, y: 10 }}
           whileInView={{ opacity: 1, y: 0 }}
           className="text-green-500 font-bold uppercase tracking-[0.3em] text-sm mb-4 block"
         >
           Our Story
         </motion.span>
         <motion.h1 
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           className="text-4xl md:text-7xl font-black mb-8 tracking-tighter"
         >
           Reversing damage, <span className="gradient-text italic">Defining Rituals.</span>
         </motion.h1>
         <motion.div 
           initial={{ scaleX: 0 }}
           whileInView={{ scaleX: 1 }}
           className="h-px w-32 bg-green-500 mx-auto"
         ></motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
         <motion.div 
           initial={{ opacity: 0, x: -30 }}
           whileInView={{ opacity: 1, x: 0 }}
           className="glass p-1 rounded-[3rem] border-white/5 relative group"
         >
            <div className="absolute inset-0 bg-green-500/20 blur-[100px] rounded-full group-hover:bg-green-500/30 transition-all"></div>
            <img 
               src="https://images.unsplash.com/photo-1590439471364-192aa70c0b53?q=80&w=2787&auto=format&fit=crop" 
               alt="About Us" 
               className="relative rounded-[2.8rem] w-full aspect-4/5 object-cover grayscale brightness-75 group-hover:grayscale-0 transition-all duration-1000" 
            />
            <div className="absolute bottom-12 right-12 glass p-8 rounded-3xl border-white/10 backdrop-blur-xl">
               <Quote className="text-green-400 mb-4" size={32} />
               <p className="text-xl font-bold italic">Results you can truly feel.</p>
            </div>
         </motion.div>

         <motion.div 
           initial={{ opacity: 0, x: 30 }}
           whileInView={{ opacity: 1, x: 0 }}
           className="space-y-8"
         >
            <h2 className="text-3xl md:text-5xl font-black tracking-tight leading-tight">Born from <span className="text-green-400">Personal Experience.</span></h2>
            <p className="text-white/60 text-xl leading-relaxed">
               Our journey began with a simple goal — to solve common hair concerns like hair fall and dandruff. 
               After struggling with these issues personally, we began experimenting with traditional herbal formulations. 
               With consistent use, we experienced visible transformation — stronger roots, reduced hair fall, and healthier growth.
            </p>
            <p className="text-white/60 text-xl leading-relaxed">
               Every product is thoughtfully crafted, tested, and used personally to ensure it delivers visible and consistent results. 
               We believe in combining the power of nature with the right formulations to promote healthy, strong, and beautiful hair.
            </p>
            
            <div className="pt-8 border-t border-white/5">
                <h4 className="text-2xl font-black mb-1">R. Sadiq Basha</h4>
                <p className="text-green-500 font-bold uppercase tracking-widest text-sm">Founder, Reverse Rituals</p>
            </div>
         </motion.div>
      </div>

      {/* Philosophy Section */}
      <div className="glass p-12 md:p-24 rounded-[4rem] border-white/5 bg-white/[0.02] mb-32 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/5 blur-[120px] rounded-full"></div>
         
         <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-6xl font-black mb-12 tracking-tighter">Why <span className="gradient-text">Reverse Rituals?</span></h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-left">
               <div className="space-y-4">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 italic text-2xl font-black text-green-400">R</div>
                     <h3 className="text-2xl font-black uppercase tracking-widest italic">Reverse</h3>
                  </div>
                  <p className="text-white/40 leading-relaxed text-lg pl-16">
                     To undo, repair, or bring back to a better condition. Our name symbolizes a journey of reversing damage and restoring natural balance.
                  </p>
               </div>
               <div className="space-y-4">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 italic text-2xl font-black text-blue-400">R</div>
                     <h3 className="text-2xl font-black uppercase tracking-widest italic">Rituals</h3>
                  </div>
                  <p className="text-white/40 leading-relaxed text-lg pl-16">
                     Regular self-care practices or routines. A mindful step-by-step process that brings your hair back to its healthiest, most vibrant state.
                  </p>
               </div>
            </div>
         </div>
      </div>

      {/* Core Values */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
         {[
           { icon: <Heart size={24} />, title: "Honesty", color: "bg-red-500/20 text-red-400" },
           { icon: <ShieldCheck size={24} />, title: "Transparency", color: "bg-green-500/20 text-green-400" },
           { icon: <Sparkles size={24} />, title: "Quality", color: "bg-yellow-500/20 text-yellow-400" },
           { icon: <Zap size={24} />, title: "Results", color: "bg-blue-500/20 text-blue-400" },
         ].map((val, i) => (
            <motion.div 
               key={i}
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               transition={{ delay: i * 0.1 }}
               className="glass p-8 rounded-3xl border-white/5 flex flex-col items-center justify-center text-center group hover:bg-white/5"
            >
               <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${val.color} group-hover:scale-110 transition-transform`}>
                  {val.icon}
               </div>
               <h4 className="text-xl font-bold">{val.title}</h4>
            </motion.div>
         ))}
      </div>
    </div>
  );
};

export default AboutPage;
