import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Hero from '../components/Hero';
import ProductCard from '../components/ProductCard';
import { motion } from 'framer-motion';
import { ShoppingBag, Star, Zap, Leaf } from 'lucide-react';

import { alchemyProducts } from '../data/alchemyProducts';

const HomePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
        const { data } = await axios.get(`${API_URL}/api/products`);
        
        // Combine with alchemy products, ensuring no duplicates by name
        const backendProducts = data.filter(p => 
          !alchemyProducts.some(ap => ap.name === p.name)
        );
        setProducts([...alchemyProducts, ...backendProducts]);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching products:', error);
        // Fallback to just alchemy products if backend fails
        setProducts(alchemyProducts);
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const features = [
    { icon: <Leaf className="text-green-400" size={32} />, title: "100% Natural", desc: "No harmful chemicals or additives." },
    { icon: <Zap className="text-yellow-400" size={32} />, title: "Fast Growth", desc: "Visible results in as little as 3 weeks." },
    { icon: <Star className="text-emerald-400" size={32} />, title: "Premium Quality", desc: "Hand-picked Ayurvedic ingredients." },
  ];

  return (
    <div className="bg-[#0c0c0e]">
      <Hero />

      {/* Features Section */}
      <section className="py-24 px-6 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
        {features.map((feature, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="flex flex-col items-center text-center p-8 glass rounded-3xl group"
          >
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-white/5">
               {feature.icon}
            </div>
            <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
            <p className="text-white/40">{feature.desc}</p>
          </motion.div>
        ))}
      </section>

      {/* Products Section */}
      <section id="products" className="py-24 px-6 bg-gradient-to-b from-[#0c0c0e] to-[#121214]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8">
            <div className="max-w-2xl">
               <span className="text-green-500 font-bold uppercase tracking-widest text-sm mb-4 block">Our Collection</span>
               <h2 className="text-4xl md:text-6xl font-black mb-6">Signature Hair Care Essentials</h2>
               <p className="text-white/40 text-lg">Curated solutions for every hair type and concern. Transform your routine into a ritual.</p>
            </div>
            <div className="glass p-4 rounded-3xl border-white/10 flex items-center gap-4">
              <ShoppingBag size={24} className="text-green-400" />
              <span className="font-bold">{products.length} Products Available</span>
            </div>
          </div>

          {loading ? (
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {[1,2,3,4].map(n => (
                   <div key={n} className="h-96 glass rounded-3xl animate-pulse"></div>
                ))}
             </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
               {products.map((product) => (
                  <ProductCard key={product._id} product={product} />
               ))}
            </div>
          )}
        </div>
      </section>

      {/* Benefits CTA */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto glass rounded-[3rem] p-12 md:p-24 relative overflow-hidden flex flex-col md:flex-row items-center gap-16 border-white/5">
           <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/10 rounded-full blur-[100px] -mr-20 -mt-20"></div>
           <div className="flex-1 relative z-10 text-center md:text-left">
              <h2 className="text-4xl md:text-6xl font-black mb-8 leading-tight">Start Your <br /><span className="gradient-text">Transformation</span> Today</h2>
              <p className="text-white/60 text-xl mb-12 max-w-lg mx-auto md:mx-0">Join thousands of customers who have achieved thicker, healthier hair with Gofs HairCare.</p>
              <div className="flex flex-col sm:flex-row gap-6">
                 <a href="#products" className="btn-primary flex items-center justify-center gap-2">Order Now</a>
                 <div className="flex -space-x-3 items-center">
                    {[1,2,3,4].map(n => (
                       <div key={n} className="w-10 h-10 rounded-full border-2 border-black bg-white/10 overflow-hidden">
                          <img src={`https://i.pravatar.cc/100?u=${n}`} alt="user" />
                       </div>
                    ))}
                    <span className="ml-6 text-white/40 text-sm font-bold">5k+ Happy Customers</span>
                 </div>
              </div>
           </div>
           <div className="flex-1 relative group">
              <div className="absolute inset-0 bg-green-500/20 blur-[100px] group-hover:scale-125 transition-transform"></div>
               <img 
                 src="https://8upload.com/display/318630876ed461a1/IMG_4143__1_.JPG.php" 
                 alt="Combo Pack" 
                 className="relative z-10 w-full h-[500px] object-cover rounded-3xl transform rotate-3 group-hover:rotate-0 transition-transform duration-700" 
              />
           </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
