import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Trash2, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { motion, AnimatePresence } from 'framer-motion';

const CartPage = () => {
  const { cartItems, removeFromCart, cartTotal } = useCart();
  const navigate = useNavigate();

  if (cartItems.length === 0) {
    return (
      <div className="h-screen pt-32 flex flex-col items-center justify-center text-center px-6">
        <ShoppingCart size={128} className="text-white/5 mb-12" />
        <h2 className="text-4xl font-black mb-6">Your Cart is Empty</h2>
        <p className="text-white/40 text-xl mb-12 max-w-sm">Looks like you haven't added anything to your cart yet. Time to start shopping!</p>
        <Link to="/" className="btn-primary">Browse Products</Link>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto">
      <h1 className="text-4xl md:text-6xl font-black mb-16 tracking-tighter">Your Shopping <span className="gradient-text">Basket</span></h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 items-start">
        <div className="lg:col-span-2 space-y-6">
          <AnimatePresence>
            {cartItems.map((item) => (
              <motion.div
                 key={item._id}
                 initial={{ opacity: 0, x: -20 }}
                 animate={{ opacity: 1, x: 0 }}
                 exit={{ opacity: 0, x: 20 }}
                 className="glass rounded-[2rem] p-6 flex flex-col sm:flex-row items-center gap-8 border-white/5 bg-white/5 group"
              >
                <div className="w-32 h-32 rounded-2xl overflow-hidden shadow-2xl relative group-hover:scale-105 transition-transform">
                   <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-grow text-center sm:text-left">
                   <h3 className="text-2xl font-bold mb-2">{item.name}</h3>
                   <p className="text-white/40 mb-2">Quantity: {item.qty}</p>
                   <div className="text-xl font-bold text-green-400">₹{item.price} each</div>
                </div>

                <div className="flex items-center gap-6">
                   <div className="text-2xl font-black text-white/80">₹{item.price * item.qty}</div>
                   <button 
                     onClick={() => removeFromCart(item._id)}
                     className="w-14 h-14 rounded-2xl glass border border-red-500/10 flex items-center justify-center text-red-400 hover:bg-red-500 hover:text-white transition-all transform active:scale-95"
                   >
                      <Trash2 size={24} />
                   </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           animate={{ opacity: 1, scale: 1 }}
           className="glass rounded-[3rem] p-10 border-white/10 relative overflow-hidden"
        >
           <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>
           
           <h3 className="text-3xl font-black mb-10 pb-6 border-b border-white/5">Order Summary</h3>
           
           <div className="space-y-6 mb-12">
              <div className="flex justify-between items-center text-white/60">
                 <span>Subtotal</span>
                 <span className="font-bold">₹{cartTotal}</span>
              </div>
              <div className="flex justify-between items-center text-white/60">
                 <span>Shipping</span>
                 <span className="text-green-400 font-bold">FREE</span>
              </div>
              <div className="pt-6 border-t border-white/5 flex justify-between items-center text-2xl font-black">
                 <span>Total</span>
                 <span className="gradient-text drop-shadow-[0_0_10px_rgba(34,197,94,0.3)]">₹{cartTotal}</span>
              </div>
           </div>

           <button 
             onClick={() => navigate('/checkout')}
             className="w-full btn-primary flex items-center justify-center gap-3 py-6 text-xl"
           >
              Proceed to Payment
              <ArrowRight size={24} className="animate-pulse" />
           </button>
           
           <p className="mt-8 text-center text-white/20 text-sm">Secure checkout powered by Razorpay</p>
        </motion.div>
      </div>
    </div>
  );
};

export default CartPage;
