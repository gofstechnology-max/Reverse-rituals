import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { ShoppingBag, Package, Truck, CheckCircle, Trash2, Edit3, Plus, X, List, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-toastify';

const AdminPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('orders'); // orders, products
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Product form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    image: '',
    category: '',
    countInStock: '',
  });

  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate('/login');
    } else {
      fetchData();
    }
  }, [user, navigate]);

  const fetchData = async () => {
    setLoading(true);
    const config = {
      headers: { Authorization: `Bearer ${user.token}` },
    };
    try {
      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
      const [ordersRes, productsRes] = await Promise.all([
        axios.get(`${API_URL}/api/orders`, config),
        axios.get(`${API_URL}/api/products`, config)
      ]);
      setOrders(ordersRes.data);
      setProducts(productsRes.data);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  const handleDeliver = async (id) => {
    const config = {
      headers: { Authorization: `Bearer ${user.token}` },
    };
    try {
      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
      await axios.put(`${API_URL}/api/orders/${id}/deliver`, {}, config);
      toast.success('Order marked as delivered!');
      fetchData();
    } catch (error) {
      toast.error('Update failed');
    }
  };

  const handleDeleteProduct = async (id) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      const config = {
        headers: { Authorization: `Bearer ${user.token}` },
      };
      try {
        const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
        await axios.delete(`${API_URL}/api/products/${id}`, config);
        toast.success('Product deleted!');
        fetchData();
      } catch (error) {
        toast.error('Deletion failed');
      }
    }
  };

  const handleProductSubmit = async (e) => {
    e.preventDefault();
    const config = {
      headers: { Authorization: `Bearer ${user.token}` },
    };
    try {
      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
      if (editingProduct) {
        await axios.put(`${API_URL}/api/products/${editingProduct._id}`, formData, config);
        toast.success('Product updated!');
      } else {
        await axios.post(`${API_URL}/api/products`, formData, config);
        toast.success('Product created!');
      }
      setIsModalOpen(false);
      setEditingProduct(null);
      setFormData({ name: '', price: '', description: '', image: '', category: '', countInStock: '' });
      fetchData();
    } catch (error) {
      toast.error('Operation failed');
    }
  };

  const openEditModal = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      price: product.price,
      description: product.description,
      image: product.image,
      category: product.category,
      countInStock: product.countInStock,
    });
    setIsModalOpen(true);
  };

  if (loading) return <div className="h-screen pt-32 flex items-center justify-center"><div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div></div>;

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
         <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-black mb-4 tracking-tighter">Admin <span className="gradient-text">Dashboard</span></h1>
            <p className="text-white/40">Manage your orders, products, and customer ritual fulfillment.</p>
         </div>
      </div>

      <div className="flex items-center gap-6 mb-12 p-2 glass rounded-3xl w-fit border-white/5">
         <button 
           onClick={() => setActiveTab('orders')}
           className={`px-8 py-4 rounded-2xl flex items-center gap-3 font-bold transition-all ${activeTab === 'orders' ? 'bg-green-500 text-black shadow-lg shadow-green-500/20' : 'hover:bg-white/5'}`}
         >
           <ShoppingBag size={20} /> Orders <span>({orders.length})</span>
         </button>
         <button 
           onClick={() => setActiveTab('products')}
           className={`px-8 py-4 rounded-2xl flex items-center gap-3 font-bold transition-all ${activeTab === 'products' ? 'bg-green-500 text-black shadow-lg shadow-green-500/20' : 'hover:bg-white/5'}`}
         >
           <Package size={20} /> Products <span>({products.length})</span>
         </button>
      </div>

      <AnimatePresence mode="wait">
         {activeTab === 'orders' ? (
           <motion.div 
             key="orders"
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             exit={{ opacity: 0 }}
             className="grid grid-cols-1 gap-6"
           >
              {orders.map((order) => (
                 <div key={order._id} className="glass rounded-[2rem] p-8 border-white/5 group relative overflow-hidden">
                    <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-8 mb-8 pb-8 border-b border-white/5">
                       <div className="space-y-2">
                          <div className="flex items-center gap-3 mb-2">
                             <span className="text-white/30 text-xs font-mono uppercase">Order #{order._id.slice(-8)}</span>
                             {order.isPaid ? (
                                <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs font-bold uppercase tracking-widest">Paid</span>
                             ) : (
                                <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-xs font-bold uppercase tracking-widest">Unpaid</span>
                             )}
                          </div>
                          <h3 className="text-2xl font-bold">{order.shippingAddress.fullName}</h3>
                          <div className="flex items-center gap-4 text-white/40 text-sm">
                             <div className="flex items-center gap-1"><Truck size={14} /> ₹{order.totalPrice}</div>
                             <div className="flex items-center gap-1"><Package size={14} /> {order.orderItems.length} Items</div>
                             <div className="flex items-center gap-1"><List size={14} /> {new Date(order.createdAt).toLocaleDateString()}</div>
                          </div>
                       </div>

                       <div className="flex items-center gap-4">
                          {!order.isDelivered && (
                             <button 
                               onClick={() => handleDeliver(order._id)}
                               className="btn-primary py-3 px-6 flex items-center gap-2 text-sm"
                             >
                                <CheckCircle size={18} /> Mark Delivered
                             </button>
                          )}
                          {order.isDelivered && (
                             <div className="flex items-center gap-2 text-green-400 font-bold glass px-6 py-3 rounded-full border-green-500/20">
                                <CheckCircle size={20} /> Delivered {new Date(order.deliveredAt).toLocaleDateString()}
                             </div>
                          )}
                       </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
                       {order.orderItems.map((item, idx) => (
                          <div key={idx} className="space-y-2 group/item">
                             <img src={item.image} alt={item.name} className="w-full aspect-square object-cover rounded-2xl grayscale group-hover/item:grayscale-0 transition-all shadow-xl" />
                             <p className="text-[10px] font-bold truncate opacity-40 uppercase tracking-widest">{item.name}</p>
                          </div>
                       ))}
                    </div>
                 </div>
              ))}
              {orders.length === 0 && <div className="text-center py-20 glass rounded-[2rem] text-white/20">No orders found.</div>}
           </motion.div>
         ) : (
           <motion.div 
             key="products"
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             exit={{ opacity: 0 }}
             className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
           >
              <button 
                onClick={() => { setEditingProduct(null); setFormData({ name: '', price: '', description: '', image: '', category: '', countInStock: '' }); setIsModalOpen(true); }}
                className="glass rounded-[2rem] border-white/5 border-dashed border-2 flex flex-col items-center justify-center gap-6 p-12 text-white/20 hover:text-green-400 hover:border-green-500/40 transition-all group"
              >
                 <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Plus size={40} />
                 </div>
                 <span className="text-xl font-bold">Add New Product</span>
              </button>

              {products.map((product) => (
                 <div key={product._id} className="glass rounded-[2rem] p-8 border-white/5 group h-full flex flex-col">
                    <img src={product.image} alt={product.name} className="w-full aspect-square object-cover rounded-2xl mb-6 shadow-2xl" />
                    <h3 className="text-2xl font-bold mb-2">{product.name}</h3>
                    <p className="text-green-400 font-black text-xl mb- auto">₹{product.price}</p>
                    <div className="flex items-center gap-4 mt-8 pt-6 border-t border-white/5">
                       <button onClick={() => openEditModal(product)} className="flex-1 glass py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-green-500 hover:text-black font-bold transition-all">
                          <Edit3 size={18} /> Edit
                       </button>
                       <button onClick={() => handleDeleteProduct(product._id)} className="flex-1 glass py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-red-500 text-red-500 hover:text-white font-bold transition-all border-red-500/10">
                          <Trash2 size={18} /> Delete
                       </button>
                    </div>
                 </div>
              ))}
           </motion.div>
         )}
      </AnimatePresence>

      {/* Modal for Product Add/Edit */}
      <AnimatePresence>
         {isModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-24 bg-black/80 backdrop-blur-md">
               <motion.div 
                 initial={{ opacity: 0, scale: 0.9, y: 20 }}
                 animate={{ opacity: 1, scale: 1, y: 0 }}
                 exit={{ opacity: 0, scale: 0.9, y: 20 }}
                 className="glass rounded-[3rem] p-12 w-full max-w-4xl border-white/10 relative overflow-y-auto max-h-[90vh]"
               >
                  <button onClick={() => setIsModalOpen(false)} className="absolute top-8 right-8 text-white/40 hover:text-white"><X size={32} /></button>
                  <h2 className="text-4xl font-black mb-12 tracking-tighter">{editingProduct ? 'Edit Product' : 'Add New Product'}</h2>
                  
                  <form onSubmit={handleProductSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <div className="space-y-6">
                        <div>
                           <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Product Name</label>
                           <input 
                             type="text" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})}
                             className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                           />
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                           <div>
                              <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Price (₹)</label>
                              <input 
                                type="number" required value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})}
                                className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                              />
                           </div>
                           <div>
                              <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Stock</label>
                              <input 
                                type="number" required value={formData.countInStock} onChange={(e) => setFormData({...formData, countInStock: e.target.value})}
                                className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                              />
                           </div>
                        </div>
                        <div>
                           <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Category</label>
                           <input 
                             type="text" required value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})}
                             className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                           />
                        </div>
                     </div>
                     <div className="space-y-6">
                        <div>
                           <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Hosted Image URL</label>
                           <input 
                             type="text" required value={formData.image} onChange={(e) => setFormData({...formData, image: e.target.value})}
                             className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                           />
                        </div>
                        <div>
                           <label className="block text-white/40 text-sm mb-2 font-bold uppercase tracking-widest pl-2">Description</label>
                           <textarea 
                             required rows="5" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})}
                             className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 text-lg"
                           ></textarea>
                        </div>
                        
                        <button type="submit" className="w-full btn-primary py-6 text-xl">
                           {editingProduct ? 'Save Changes' : 'Create Product'}
                        </button>
                     </div>
                  </form>
               </motion.div>
            </div>
         )}
      </AnimatePresence>
    </div>
  );
};

export default AdminPage;
