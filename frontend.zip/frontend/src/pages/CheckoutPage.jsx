import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, MapPin, Phone, User, ArrowRight, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { toast } from 'react-toastify';

const CheckoutPage = () => {
  const { cartItems, cartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (cartItems.length === 0) {
      navigate('/cart');
    }
  }, [cartItems, navigate]);

  const loadRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handlePayment = async (e) => {
    e.preventDefault();

    const res = await loadRazorpay();
    if (!res) {
      toast.error('Razorpay SDK failed to load. Are you online?');
      return;
    }

    try {
      // 1. Create order on backend
      const orderConfig = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: user ? `Bearer ${user.token}` : undefined,
        },
      };

      const orderData = {
        orderItems: cartItems.map(item => ({
          name: item.name,
          qty: item.qty,
          image: item.image,
          price: item.price,
          product: item._id,
        })),
        shippingAddress: {
          fullName: user ? user.name : 'Guest User',
          address,
          city,
          zipCode,
          country: 'India',
          phone,
        },
        itemsPrice: cartTotal,
        shippingPrice: 0,
        totalPrice: cartTotal,
      };

      const { data } = await axios.post(`${import.meta.env.VITE_API_URL || 'http://localhost:5001'}/api/orders`, orderData, orderConfig);
      
      const { order, razorpayOrder } = data;

      // 2. Open Razorpay Checkout
      const options = {
        key: 'rzp_test_SXrg4UT1hSVB4n',
        amount: razorpayOrder.amount,
        currency: razorpayOrder.currency,
        name: 'Gofs HairCare',
        description: 'Payment for your hair transformation',
        order_id: razorpayOrder.id,
        handler: async (response) => {
          try {
            const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001';
            const verifyRes = await axios.post(`${API_URL}/api/orders/verify`, {
              ...response,
              orderId: order._id,
            });
            
            if (verifyRes.data.message === "Payment verified successfully") {
              toast.success('Payment Successful! Thank you for your order.');
              clearCart();
              navigate('/');
            }
          } catch (err) {
            toast.error('Payment verification failed');
          }
        },
        prefill: {
          name: user ? user.name : '',
          email: user ? user.email : '',
          contact: phone,
        },
        theme: {
          color: '#22c55e',
        },
      };

      const paymentObject = new window.Razorpay(options);
      paymentObject.open();

    } catch (error) {
      toast.error(error.response?.data?.message || 'Checkout failed');
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 max-w-7xl mx-auto">
      <h1 className="text-4xl md:text-6xl font-black mb-16 tracking-tighter">Shipping <span className="gradient-text">Details</span></h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        <motion.div
           initial={{ opacity: 0, x: -20 }}
           animate={{ opacity: 1, x: 0 }}
        >
           <form onSubmit={handlePayment} className="space-y-8">
              <div className="glass p-10 rounded-[3rem] border-white/10 space-y-8">
                 <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-green-500/20 rounded-2xl flex items-center justify-center">
                       <MapPin className="text-green-400" />
                    </div>
                    <h3 className="text-2xl font-bold">Shipping Address</h3>
                 </div>

                 <div className="space-y-6">
                    <div className="relative group">
                       <MapPin className="absolute left-6 top-6 text-white/20 group-focus-within:text-green-400" size={20} />
                       <textarea 
                          required
                          placeholder="Complete Address" 
                          rows="3"
                          className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                       ></textarea>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                       <div className="relative group">
                          <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-green-400" size={20} />
                          <input 
                            type="text" 
                            required
                            placeholder="City" 
                            className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                          />
                       </div>
                       <div className="relative group">
                          <ShieldCheck className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-green-400" size={20} />
                          <input 
                            type="text" 
                            required
                            placeholder="Zip Code" 
                            className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                            value={zipCode}
                            onChange={(e) => setZipCode(e.target.value)}
                          />
                       </div>
                    </div>

                    <div className="relative group">
                       <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-white/20 group-focus-within:text-green-400" size={20} />
                       <input 
                         type="tel" 
                         required
                         placeholder="Phone Number" 
                         className="w-full pl-16 pr-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-green-500 focus:bg-white/10 transition-all text-lg"
                         value={phone}
                         onChange={(e) => setPhone(e.target.value)}
                       />
                    </div>
                 </div>
              </div>

              <button type="submit" className="w-full btn-primary flex items-center justify-center gap-3 py-6 text-xl font-black">
                 Pay ₹{cartTotal} Now
                 <CreditCard size={24} />
              </button>
           </form>
        </motion.div>

        <motion.div
           initial={{ opacity: 0, x: 20 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ delay: 0.2 }}
           className="space-y-8"
        >
           <div className="glass p-10 rounded-[3rem] border-white/10">
              <h3 className="text-2xl font-bold mb-8">Order Overview</h3>
              <div className="space-y-6 max-h-[400px] overflow-y-auto pr-4 custom-scrollbar">
                 {cartItems.map((item) => (
                    <div key={item._id} className="flex items-center gap-6 pb-6 border-b border-white/5">
                       <img src={item.image} alt={item.name} className="w-20 h-20 rounded-xl object-cover" />
                       <div className="flex-grow">
                          <h4 className="font-bold mb-1">{item.name}</h4>
                          <p className="text-white/40 text-sm">Qty: {item.qty} × ₹{item.price}</p>
                       </div>
                       <div className="font-bold text-green-400">₹{item.price * item.qty}</div>
                    </div>
                 ))}
              </div>

              <div className="mt-8 space-y-4">
                 <div className="flex justify-between items-center text-white/60">
                    <span>Subtotal</span>
                    <span className="font-bold">₹{cartTotal}</span>
                 </div>
                 <div className="flex justify-between items-center text-white/60">
                    <span>Shipping</span>
                    <span className="text-green-400 font-bold">FREE</span>
                 </div>
                 <div className="pt-6 border-t border-white/5 flex justify-between items-center text-3xl font-black">
                    <span>Total</span>
                    <span className="gradient-text">₹{cartTotal}</span>
                 </div>
              </div>
           </div>

           <div className="p-8 glass rounded-3xl border-emerald-500/20 bg-emerald-500/5 flex items-start gap-4">
              <ShieldCheck className="text-green-400 shrink-0" size={24} />
              <div>
                 <h4 className="font-bold mb-1">Secure Checkout</h4>
                 <p className="text-white/40 text-sm">Your payment data is encrypted and secure. We never store your card details.</p>
              </div>
           </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CheckoutPage;
